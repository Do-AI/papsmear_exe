# papsmear agent
golang을 사용한 Agent 프로그램

### godoc
```bash
godoc -http=localhost:8080
```
위의 명령어를 terminal에서 실행 한 후 아래 url로 internal package 문서를 볼 수 있다.  

[godoc internal package](http://localhost:8080/pkg/github.com/p829911/agent/papsmear/internal/)

